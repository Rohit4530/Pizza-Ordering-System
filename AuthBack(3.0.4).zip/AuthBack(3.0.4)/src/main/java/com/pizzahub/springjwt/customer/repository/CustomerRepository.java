package com.pizzahub.springjwt.customer.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pizzahub.springjwt.customer.entity.AppCustomer;

public interface CustomerRepository extends JpaRepository<AppCustomer , Long> {

	Optional<AppCustomer> findByuserId(Long userId);

}
