package com.pizzahub.springjwt.customer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pizzahub.springjwt.customer.entity.AppCustomer;
import com.pizzahub.springjwt.customer.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private CustomerRepository repo;
	
	public List<AppCustomer>getAllCustomer(){
		return repo.findAll();
	}
	public AppCustomer addCustomer(AppCustomer customer) {
	  return repo.save(customer);
	}
	public AppCustomer updateCustomer(AppCustomer customer) {
		  return repo.save(customer);
	}
	public void deleteCustomer(Long id) {
		repo.deleteById(id);
	}
	public AppCustomer getCustomer(Long userId) {
		Optional<AppCustomer>customer=repo.findByuserId(userId);
		return customer.get();
	}
	public double getWalletAmount(Long userId) {
	return 	getCustomer(userId).getWalletAmount();
		
	}
	public double setWalletAmount (Long userId,Long walletAmount) {
		AppCustomer customer=getCustomer(userId);
		long prev=customer.getWalletAmount();
		customer.setWalletAmount(prev+walletAmount);
		repo.save(customer);
	return customer.getWalletAmount();
	}
	public double makePayment(Long userId,double payment) {
		AppCustomer customer=getCustomer(userId);
		double prev=customer.getWalletAmount();
		customer.setWalletAmount((long)(prev-payment));
		repo.save(customer);
	return customer.getWalletAmount();
	
	}
	
}
