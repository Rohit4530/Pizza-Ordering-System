package com.pizzahub.springjwt.controllers;

import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pizzahub.springjwt.models.User;
import com.pizzahub.springjwt.payload.request.LoginRequest;
import com.pizzahub.springjwt.payload.request.SignupRequest;
import com.pizzahub.springjwt.repository.RoleRepository;
import com.pizzahub.springjwt.repository.UserRepository;
import com.pizzahub.springjwt.security.jwt.JwtUtils;
import com.pizzahub.springjwt.security.services.UserDetailsImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.TestingAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

@ContextConfiguration(classes = {AuthController.class})
@ExtendWith(SpringExtension.class)
class AuthControllerTest {
    @Autowired
    private AuthController authController;

    @MockBean
    private AuthenticationManager authenticationManager;

    @MockBean
    private JwtUtils jwtUtils;

    @MockBean
    private PasswordEncoder passwordEncoder;

    @MockBean
    private RoleRepository roleRepository;

    @MockBean
    private UserRepository userRepository;
    @Test
    void testAuthenticateUser() throws Exception {
        when(jwtUtils.generateJwtToken((Authentication) any())).thenReturn("ABC123");
        when(authenticationManager.authenticate((Authentication) any())).thenReturn(new TestingAuthenticationToken(
                new UserDetailsImpl(1L, "testusername", "test@example.org", "testpassword", new ArrayList<>()), "Credentials"));

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setPassword("testpassowrd");
        loginRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(loginRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signin")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content()
                        .string(
                                "{\"id\":1,\"username\":\"testusername\",\"email\":\"test@example.org\",\"roles\":[],\"accessToken\":\"ABC123\",\"tokenType"
                                        + "\":\"Bearer\"}"));
    }
    @Test
    void testAuthenticateUser2() throws Exception {
        when(jwtUtils.generateJwtToken((Authentication) any())).thenReturn("ABC123");
        when(authenticationManager.authenticate((Authentication) any()))
                .thenReturn(new TestingAuthenticationToken("Principal", "Credentials"));

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setPassword("");
        loginRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(loginRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signin")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400));
    }
    @Test
    void testForget() throws Exception {
        User user = new User();
        user.setEmail("test@example.org");
        user.setId(1L);
        user.setPassword("testpassword");
        user.setRoles(new HashSet<>());
        user.setUsername("testusername");
        Optional<User> ofResult = Optional.of(user);

        User user1 = new User();
        user1.setEmail("test@example.org");
        user1.setId(1L);
        user1.setPassword("testpassword");
        user1.setRoles(new HashSet<>());
        user1.setUsername("testusername");
        when(userRepository.save((User) any())).thenReturn(user1);
        when(userRepository.findByUsername((String) any())).thenReturn(ofResult);
        when(passwordEncoder.encode((CharSequence) any())).thenReturn("secret");

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setPassword("testpassword");
        loginRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(loginRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.put("/api/auth/signin/forget")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder)
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"Password changed successfully\"}"));
    }
    @Test
    void testForget2() throws Exception {
        User user = new User();
        user.setEmail("test@example.org");
        user.setId(1L);
        user.setPassword("testpassword");
        user.setRoles(new HashSet<>());
        user.setUsername("testusername");
        Optional<User> ofResult = Optional.of(user);

        User user1 = new User();
        user1.setEmail("test@example.org");
        user1.setId(1L);
        user1.setPassword("testpassword");
        user1.setRoles(new HashSet<>());
        user1.setUsername("testusername");
        when(userRepository.save((User) any())).thenReturn(user1);
        when(userRepository.findByUsername((String) any())).thenReturn(ofResult);
        when(passwordEncoder.encode((CharSequence) any())).thenThrow(new RuntimeException());

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setPassword("testpassword");
        loginRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(loginRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.put("/api/auth/signin/forget")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400))
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"Error: User is not Registered!\"}"));
    }

    @Test
    void testForget3() throws Exception {
        User user = new User();
        user.setEmail("test@example.org");
        user.setId(1L);
        user.setPassword("testpassword");
        user.setRoles(new HashSet<>());
        user.setUsername("testusername");
        when(userRepository.save((User) any())).thenReturn(user);
        when(userRepository.findByUsername((String) any())).thenReturn(null);
        when(passwordEncoder.encode((CharSequence) any())).thenReturn("secret");

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setPassword("testpassword");
        loginRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(loginRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.put("/api/auth/signin/forget")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400))
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"Error: User is not Registered!\"}"));
    }
    @Test
    void testForget4() throws Exception {
        User user = new User();
        user.setEmail("test@example.org");
        user.setId(1L);
        user.setPassword("testpassword");
        user.setRoles(new HashSet<>());
        user.setUsername("testusername");
        Optional<User> ofResult = Optional.of(user);

        User user1 = new User();
        user1.setEmail("test@example.org");
        user1.setId(1L);
        user1.setPassword("testpassword");
        user1.setRoles(new HashSet<>());
        user1.setUsername("testusername");
        when(userRepository.save((User) any())).thenReturn(user1);
        when(userRepository.findByUsername((String) any())).thenReturn(ofResult);
        when(passwordEncoder.encode((CharSequence) any())).thenReturn("secret");

        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setPassword(null);
        loginRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(loginRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.put("/api/auth/signin/forget")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400));
    }
    @Test
    void testRegisterUser() throws Exception {
        User user = new User();
        user.setEmail("test@example.org");
        user.setId(1L);
        user.setPassword("testpassword");
        user.setRoles(new HashSet<>());
        user.setUsername("testusername");
        when(userRepository.existsByEmail((String) any())).thenReturn(true);
        when(userRepository.existsByUsername((String) any())).thenReturn(true);
        when(userRepository.save((User) any())).thenReturn(user);

        SignupRequest signupRequest = new SignupRequest();
        signupRequest.setEmail("test@example.org");
        signupRequest.setPassword("testpassword");
        signupRequest.setRole(new HashSet<>());
        signupRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(signupRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400))
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"Error: Username is already taken!\"}"));
    }
    @Test
    void testRegisterUser2() throws Exception {
        User user = new User();
        user.setEmail("test@example.org");
        user.setId(1L);
        user.setPassword("testpassword");
        user.setRoles(new HashSet<>());
        user.setUsername("testusername");
        when(userRepository.existsByEmail((String) any())).thenReturn(true);
        when(userRepository.existsByUsername((String) any())).thenReturn(false);
        when(userRepository.save((User) any())).thenReturn(user);

        SignupRequest signupRequest = new SignupRequest();
        signupRequest.setEmail("test@example.org");
        signupRequest.setPassword("testpassword");
        signupRequest.setRole(new HashSet<>());
        signupRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(signupRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400))
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"Error: Email is already in use!\"}"));
    }
    @Test
    void testRegisterUser3() throws Exception {
        User user = new User();
        user.setEmail("test@example.org");
        user.setId(1L);
        user.setPassword("testpassword");
        user.setRoles(new HashSet<>());
        user.setUsername("testusername");
        when(userRepository.existsByEmail((String) any())).thenReturn(true);
        when(userRepository.existsByUsername((String) any())).thenReturn(true);
        when(userRepository.save((User) any())).thenReturn(user);

        SignupRequest signupRequest = new SignupRequest();
        signupRequest.setEmail("?");
        signupRequest.setPassword("testpassword");
        signupRequest.setRole(new HashSet<>());
        signupRequest.setUsername("testusername");
        String content = (new ObjectMapper()).writeValueAsString(signupRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(400));
    }
    @Test
    void testRegisterUser4() throws Exception {

        SignupRequest signupRequest = new SignupRequest();
        signupRequest.setEmail("test@example.org");
        signupRequest.setPassword("testpassword");
        signupRequest.setRole(new HashSet<>());
        signupRequest.setUsername("testuser");
        String content = (new ObjectMapper()).writeValueAsString(signupRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(200))
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"User registered successfully!\"}"));
    }
    @Test
    void testRegisterUser5() throws Exception {

        SignupRequest signupRequest = new SignupRequest();
        signupRequest.setEmail("test@example.org");
        signupRequest.setPassword("testpassword");
        Set<String>myset=new HashSet<>();
        myset.add("admin");
        signupRequest.setRole(myset);
        signupRequest.setUsername("testuser");
        String content = (new ObjectMapper()).writeValueAsString(signupRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(200))
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"User registered successfully!\"}"));
    }
    @Test
    void testRegisterUser6() throws Exception {

        SignupRequest signupRequest = new SignupRequest();
        signupRequest.setEmail("test@example.org");
        signupRequest.setPassword("testpassword");
        signupRequest.setRole(null);
        signupRequest.setUsername("testuser");
        String content = (new ObjectMapper()).writeValueAsString(signupRequest);
        MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(content);
        ResultActions actualPerformResult = MockMvcBuilders.standaloneSetup(authController)
                .build()
                .perform(requestBuilder);
        actualPerformResult.andExpect(MockMvcResultMatchers.status().is(200))
                .andExpect(MockMvcResultMatchers.content().contentType("application/json"))
                .andExpect(MockMvcResultMatchers.content().string("{\"message\":\"User registered successfully!\"}"));
    }
}

