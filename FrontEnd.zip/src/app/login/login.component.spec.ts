import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LoginComponent } from './login.component';
import { AuthService } from '../_services/auth.service';
import { StorageService } from '../_services/storage.service';
import { of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let authServiceSpy: jasmine.SpyObj<AuthService>;
  let storageServiceSpy: jasmine.SpyObj<StorageService>;

  beforeEach(async () => {
    authServiceSpy = jasmine.createSpyObj('AuthService', ['login']);
    storageServiceSpy = jasmine.createSpyObj('StorageService', ['saveUser', 'getUser', 'isLoggedIn']);

    await TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports:[HttpClientModule, FormsModule],
      providers: [
        { provide: AuthService, useValue: authServiceSpy },
        { provide: StorageService, useValue: storageServiceSpy }
      ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set isLoggedIn to true if user is already logged in', () => {
    // Arrange
    storageServiceSpy.isLoggedIn.and.returnValue(true);
    storageServiceSpy.getUser.and.returnValue({ roles: ['ROLE_USER'] });

    // Act
    component.ngOnInit();

    // Assert
    expect(component.isLoggedIn).toBe(true);
    expect(component.roles).toEqual(['ROLE_USER']);
  });

  it('should set isLoginFailed to true and errorMessage on login failure', () => {
    // Arrange
    const errorResponse = { error: { message: 'Invalid username or password' } };
    authServiceSpy.login.and.returnValue(of(errorResponse));

    // Act
    component.onSubmit();

    // Assert
    expect(component.isLoginFailed).toBe(true);
    expect(component.errorMessage).toBe('Invalid username or password');
  });

  it('should set isLoggedIn to true and save user on login success', () => {
    // Arrange
    const token = 'sample-access-token';
    const successResponse = { accessToken: token };
    authServiceSpy.login.and.returnValue(of(successResponse));

    // Act
    component.onSubmit();

    // Assert
    expect(component.isLoggedIn).toBe(true);
    expect(storageServiceSpy.saveUser).toHaveBeenCalledWith(successResponse);
  });

  it('should call reloadPage() on login success', () => {
    // Arrange
    const token = 'sample-access-token';
    const successResponse = { accessToken: token };
    authServiceSpy.login.and.returnValue(of(successResponse));
    spyOn(component, 'reloadPage');

    // Act
    component.onSubmit();

    // Assert
    expect(component.reloadPage).toHaveBeenCalled();
  });

  it('should call window.location.reload() on reloadPage()', () => {
    // Arrange
    spyOn(window.location, 'reload');

    // Act
    component.reloadPage();

    // Assert
    expect(window.location.reload).toHaveBeenCalled();
  });
});
