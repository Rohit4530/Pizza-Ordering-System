import { FilterPipe } from './filter.pipe';
import { StorageService } from './_services/storage.service';

describe('FilterPipe', () => {
  let pipe: FilterPipe;
  let storageService: StorageService;

  beforeEach(() => {
    storageService = jasmine.createSpyObj('StorageService', ['isPizzaItem', 'isSideItem']);
    pipe = new FilterPipe(storageService);
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  // it('should return items when searchText is empty', () => {
  //   const items = [{ pizzaName: 'Margherita' }, { pizzaName: 'Pepperoni' }];
  //   const searchText = '';
  //   const result = pipe.transform(items, searchText);
  //   expect(result).toEqual(items);
  // });

  // it('should return filtered items for pizzas', () => {
  //   storageService.isPizzaItem;
  //   const items = [{ pizzaName: 'Margherita' }, { pizzaName: 'Pepperoni' }];
  //   const searchText = 'pep';
  //   const result = pipe.transform(items, searchText);
  //   expect(result.length).toEqual(1);
  //   expect(result[0].pizzaName).toEqual('Pepperoni');
  // });

  // it('should return filtered items for sides', () => {
  //   storageService.isSideItem;
  //   const items = [{ sideName: 'Garlic Bread' }, { sideName: 'Wedges' }];
  //   const searchText = 'w';
  //   const result = pipe.transform(items, searchText);
  //   expect(result.length).toEqual(1);
  //   expect(result[0].sideName).toEqual('Wedges');
  // });

  // it('should return filtered items for beverages', () => {
  //   storageService.isPizzaItem.and.returnValue(false);
  //   storageService.isSideItem.and.returnValue(false);
  //   const items = [{ beverageName: 'Coke' }, { beverageName: 'Pepsi' }];
  //   const searchText = 'co';
  //   const result = pipe.transform(items, searchText);
  //   expect(result.length).toEqual(1);
  //   expect(result[0].beverageName).toEqual('Coke');
  // });
});
