export class Beverage{
	id:number
    beverageName:string;
	beverageQuant:string;
	beveragePrice:number;
	beverageCount:number;
	imgURL:string;
    beverageDisc:string
	
}