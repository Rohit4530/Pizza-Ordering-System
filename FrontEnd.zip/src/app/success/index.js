$("button").click(function () {
    $(".check-icon").hide();
    setTimeout(function () {
       $(".check-icon").show();
    }, 10);
 });
 