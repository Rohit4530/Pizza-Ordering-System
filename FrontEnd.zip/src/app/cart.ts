import { Pizza } from "./pizza";

export class Cart {
    // productId !: number;
    id: number;
    crustId !: number;
    userId !: number;
    orderCount !: number;
    amount !: number;
    size !: string;
    imageUrl!:String;
    productName!:String
    description!:String
}

