import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { Order } from '../order';
import { OrderService } from '../_services/order.service';
import { StorageService } from '../_services/storage.service';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent implements OnInit{
  private roles: string[] = [];
  isLoggedIn = false;
  showAdminBoard = false;
  orders:Order[];
  carts :any =[];

  constructor(private orderService: OrderService,private storageService: StorageService) {}
  ngOnInit(): void {
    this.isLoggedIn = this.storageService.isLoggedIn();

    if (this.isLoggedIn) {
      const user = this.storageService.getUser();
      this.roles = user.roles;

      this.showAdminBoard = this.roles.includes('ROLE_ADMIN');

      if(!this.showAdminBoard){
    this.getOrderDetails(this.storageService.getUser().id);
      }
      else{
        this.getAdminOrderDetails();
      }
    // console.log(this.orders);
    
    
  }
}

  getOrderDetails(userId:number){
    this.orderService.getOrderByUserId(this.storageService.getUser().id).subscribe(
      data =>{
        this.orders = data;
        
        console.log(this.orders);
        for(let i=0; i<this.orders.length; i++){
          this.carts[i] = this.orders[i].cart; 
          console.log(this.carts[i].id)
        }
          
        
        console.log(this.carts);
       // console.log(this.carts[0].productName)
        
      },error=>{
        console.log(error);
        
      }
    )
  }


  //all orders for admin
  getAdminOrderDetails(){
    this.orderService.getOrder().subscribe(
      data=>{
        this.orders=data;
      },
      error=>{
        console.log("couldn't get all orders");
      }
    )
  }

  updateOrderStatus(orderId:number, orderStatus:String ){
    this.orderService.updateOrderStatus(orderId, orderStatus).subscribe(
      data=>{
        console.log(data);
      },
      error=>{
        console.log(error + "my bad")
      }

    )

  }


  getPrevoiusOrders(){
    console.log(this.orders);
    
  }
  
}
