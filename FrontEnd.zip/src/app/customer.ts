export class Customer{
    id:number;
	userId:number;
	firstName:any;
	lastName:any;
	phone:any;
    address:any;
}