import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { AuthService } from './auth.service';

describe('AuthService', () => {
  let authService: AuthService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AuthService]
    });

    authService = TestBed.inject(AuthService);
    httpTestingController = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(authService).toBeTruthy();
  });

  it('should login', () => {
    const mockResponse = { token: 'mockToken' };
    const username = 'testuser';
    const password = 'testpassword';

    authService.login(username, password).subscribe((response) => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpTestingController.expectOne('http://localhost:8585/api/auth/signin');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ username, password });
    req.flush(mockResponse);
  });

  it('should register', () => {
    const mockResponse = { message: 'User registered successfully!' };
    const username = 'testuser';
    const email = 'testuser@test.com';
    const password = 'testpassword';

    authService.register(username, email, password).subscribe((response) => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpTestingController.expectOne('http://localhost:8585/api/auth/signup');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ username, email, password });
    req.flush(mockResponse);
  });

  it('should forget password', () => {
    const mockResponse = { message: 'Password reset successful!' };
    const username = 'testuser';
    const password = 'newpassword';

    authService.forget(username, password).subscribe((response) => {
      expect(response).toEqual(mockResponse);
    });

    const req = httpTestingController.expectOne('http://localhost:8585/api/auth/signin/forget');
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual({ username, password });
    req.flush(mockResponse);
  });
});

