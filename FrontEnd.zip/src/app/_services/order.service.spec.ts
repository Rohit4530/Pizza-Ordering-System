import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Order } from '../order';
import { OrderService } from './order.service';

describe('OrderService', () => {
  let service: OrderService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [OrderService]
    });

    service = TestBed.inject(OrderService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get orders', () => {
    const orders: Order[] = [{ id: 1, userId: 1, date: new Date(), status: 'Pending', cart: [],address:'Nirlon Colony', amount:50  }];

    service.getOrder().subscribe(data => {
      expect(data).toEqual(orders);
    });

    const req = httpMock.expectOne('http://localhost:9595/order/all');
    expect(req.request.method).toBe('GET');
    req.flush(orders);
  });

  it('should add an order', () => {
    const order: Order = { id: 1, userId: 1, date: new Date(), status: 'Pending', cart: [], address:'', amount:20 };

    service.addOrder(order).subscribe(data => {
      expect(data).toEqual(order);
    });

    const req = httpMock.expectOne('http://localhost:9595/order/add');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(order);
    req.flush(order);
  });

  it('should update order status', () => {
    const id = 1;
    const status = 'Delivered';

    service.updateOrderStatus(id, status).subscribe(data => {
      expect(data).toBe(id);
    });

    const req = httpMock.expectOne(`http://localhost:9595/order/update/${id}/${status}`);
    expect(req.request.method).toBe('PUT');
    req.flush(id);
  });

  it('should delete an order', () => {
    const id = 1;

    service.deleteOrder(id).subscribe();

    const req = httpMock.expectOne(`http://localhost:9595/order/delete/${id}`);
    expect(req.request.method).toBe('DELETE');
  });

  it('should get order by user id', () => {
    const userId = 1;
    const order: Order = { id: 1, userId: 1, date: new Date(), status: 'Pending', cart: [], address:'', amount:30 };

    service.getOrderByUserId(userId).subscribe(data => {
      expect(data).toEqual(order);
    });

    const req = httpMock.expectOne(`http://localhost:9595/order/${userId}`);
    expect(req.request.method).toBe('GET');
    req.flush(order);
  });

  it('should set and get final amount', () => {
    const finalAmount = 10;

    service.setFinalAmount(finalAmount);

    expect(service.getFinalAmount()).toBe(finalAmount);
  });
});
