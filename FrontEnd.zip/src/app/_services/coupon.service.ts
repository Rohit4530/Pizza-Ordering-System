import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Coupon } from '../coupon/coupon.component';

const API_URL='http://localhost:9900/';

@Injectable({
  providedIn: 'root'
})
export class CouponService {

 
  coupon: Coupon[];
  constructor(private http: HttpClient) { }

  getCoupons(): Observable<any> {
    return this.http.get<Coupon[]>(API_URL+'coupons');

  }
  getCouponById(id:number): Observable<any> {
    return this.http.get<Coupon>(API_URL+`coupon/get/${id}`);

  }

  getCouponByName(couponName: String): Observable<any>{
    return this.http.get<Coupon>(API_URL+`coupon/${couponName}`);
  }

  addCoupon(coupon: Coupon){
    return this.http.post<Coupon>(API_URL+`coupon/add`, coupon);
  }

  updateCoupon(coupon: Coupon){
    return this.http.put<Coupon>(API_URL+`coupon/update`, coupon);
  }

  deleteCoupon(id:number){
    return this.http.delete(API_URL+`coupon/delete/${id}`);
  }

  getApplicableCoupon(orderAmount:number): Observable<any>{
    return this.http.get<Coupon[]> (API_URL + `coupon/getApplicable/${orderAmount}`);
  }

  applyCouponPrice(id:number){
    return this.http.get<number>(API_URL+`coupon/applyCoupon/${id}`);
  }

}
