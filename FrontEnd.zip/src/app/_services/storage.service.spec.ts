import { TestBed } from '@angular/core/testing';
import { StorageService } from './storage.service';

describe('StorageService', () => {
  let service: StorageService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StorageService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set and get user data', () => {
    const mockUserData = { id: 1, name: 'John Doe' };
    service.saveUser(mockUserData);
    const userData = service.getUser();
    expect(userData).toEqual(mockUserData);
  });

  it('should check if user is logged in', () => {
    service.saveUser({ id: 1, name: 'John Doe' });
    expect(service.isLoggedIn()).toBeTruthy();
    service.clean();
    expect(service.isLoggedIn()).toBeFalsy();
  });

 
});
