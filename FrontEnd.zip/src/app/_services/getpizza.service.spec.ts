import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { GetpizzaService } from './getpizza.service';
import { Beverage } from '../beverage';
import { Pizza } from '../pizza';
import { Sides } from '../sides';

describe('GetpizzaService', () => {
  let service: GetpizzaService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [GetpizzaService]
    });

    service = TestBed.inject(GetpizzaService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get list of pizzas', () => {
    const mockPizzas: Pizza[] = [
      {id: 1, pizzaName: 'Margarita', pizzaDesc: 'Classic pizza', pizzaPrice: 8.99, imgURL:'',size:'M', pizzaType:'Veg', basePrice: 8.99, pizzaCount:1},
      {id: 2, pizzaName: 'Pepperoni', pizzaDesc: 'Tomato sauce, mozzarella cheese, pepperoni', pizzaPrice: 8.99, imgURL:'',size:'M', pizzaType:'Veg', basePrice: 8.99, pizzaCount:1}
    ];

    service.getPizzaList().subscribe((pizzas: Pizza[]) => {
      expect(pizzas.length).toBe(2);
      expect(pizzas).toEqual(mockPizzas);
    });

    const req = httpMock.expectOne('http://localhost:8080/pizza/all');
    expect(req.request.method).toBe('GET');
    req.flush(mockPizzas);
  });

  it('should get a pizza by id', () => {
    const mockPizza: Pizza = {id: 1, pizzaName: 'Margarita', pizzaDesc: 'Classic pizza', pizzaPrice: 8.99, imgURL:'',size:'M', pizzaType:'Veg', basePrice: 8.99, pizzaCount:1};

    service.getPizzaById(1).subscribe((pizza: Pizza) => {
      expect(pizza).toEqual(mockPizza);
    });

    const req = httpMock.expectOne('http://localhost:8080/pizza/1');
    expect(req.request.method).toBe('GET');
    req.flush(mockPizza);
  });

  it('should get list of sides', () => {
    const mockSides: Sides[] = [
      {id: 1, sideName: 'French Fries', sideDesc: 'Fried potato sticks', sidePrice: 2.99, sideType:'veg',sideCount: 2, imgURL:''},
      {id: 2, sideName: 'Garlic Bread', sideDesc: 'Toasted bread with garlic and herbs', sidePrice: 2.99, sideType:'veg',sideCount: 2, imgURL:''}
    ];

    service.getSidesList().subscribe((sides: Sides[]) => {
      expect(sides.length).toBe(2);
      expect(sides).toEqual(mockSides);
    });

    const req = httpMock.expectOne('http://localhost:7979/sides/all');
    expect(req.request.method).toBe('GET');
    req.flush(mockSides);
  });

  it('should get list of beverages', () => {
    const mockBeverages: Beverage[] = [
      {id: 1, beverageName: 'Coca-Cola', beverageDisc: 'Carbonated soft drink', beveragePrice: 1.99, beverageCount:1, beverageQuant:'1', imgURL:''},
      {id: 2, beverageName: 'Sprite', beverageDisc: 'Lemon-lime flavored soft drink', beveragePrice:2.99, beverageCount:2, beverageQuant:'2', imgURL:''}
    ];

    service.getBevList().subscribe((beverages: Beverage[]) => {
      expect(beverages.length).toBe(2);
      expect(beverages).toEqual(mockBeverages);
    });

    const req = httpMock.expectOne('http://localhost:8181/beverages/all');
      expect(req.request.method).toBe('GET');
      req.flush(mockBeverages);
    });
  });