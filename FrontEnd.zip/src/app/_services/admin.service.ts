import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Beverage } from '../beverage';
import { Pizza } from '../pizza';
import { Sides } from '../sides';


const BEVERAGES_URL = 'http://localhost:9900/';
const SIDES_URL = 'http://localhost:9900/';


@Injectable({
  providedIn: 'root'
})


export class AdminService {



  constructor(private http:HttpClient) {
  } 

  getPizzasList(): Observable<any>{
    return this.http.get<Pizza[]>('http://localhost:9900/pizza/all');

}


getPizzaById(id:number){
  return this.http.get<Pizza>(`http://localhost:9900/pizza/find/${id}`);
}

// updatePizzaList(Pizza): {
//   return this.http.put<>('http://localhost:8080/pizza/all')
// }


updatePizzaList( id:number, pizza:Pizza){

  return this.http.put(`http://localhost:9900/pizza/update`, pizza)

}

addPizza(pizza: Pizza){
  return this.http.post('http://localhost:9900/pizza/add', pizza)
}

deletePizza(id:number){
  return this.http.delete(`http://localhost:9900/pizza/${id}`)
}




//for beverages
getBeveragesList(): Observable<any>{
  return this.http.get<Beverage[]>(BEVERAGES_URL + 'beverages/all');

}


getBeveragesById(id:number){
return this.http.get<Beverage>(BEVERAGES_URL+`beverages/get/${id}`);
}




updateBeveragesList( id:number, beverages: Beverage){

return this.http.put( BEVERAGES_URL+`beverages/update`, beverages)

}

addBeverages(beverages: Beverage){
return this.http.post(BEVERAGES_URL+ 'beverages/add', beverages)
}

deleteBeverages(id:number){
return this.http.delete(BEVERAGES_URL+`beverages/delete/${id}`)
}




//sides
getSidesList(): Observable<any>{
  return this.http.get<Sides[]>(SIDES_URL + 'sides/all');

}


getSidesById(id:number){
return this.http.get<Sides>(SIDES_URL+`sides/get/${id}`);
}




updateSidesList( id:number, sides: Sides){

return this.http.put( SIDES_URL+`sides/update`, sides)

}

addSides(sides: Sides){
return this.http.post(SIDES_URL+ 'sides/add', sides)
}

deleteSides(id:number){
return this.http.delete(SIDES_URL+`sides/delete/${id}`)
}


}
