import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { CouponService } from './coupon.service';

describe('CouponService', () => {
  let service: CouponService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ CouponService ]
    });

    service = TestBed.inject(CouponService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get all coupons', () => {
    const dummyCoupons = [
      { id: 1, couponName: 'ABC', discount: 10 },
      { id: 2, couponName: 'XYZ', discount: 20 }
    ];

    service.getCoupons().subscribe(coupons => {
      expect(coupons.length).toBe(2);
      expect(coupons).toEqual(dummyCoupons);
    });

    const req = httpMock.expectOne('http://localhost:9090/coupons');
    expect(req.request.method).toBe('GET');
    req.flush(dummyCoupons);
  });

  it('should get a coupon by ID', () => {
    const dummyCoupon = { id: 1, couponName: 'ABC', discount: 10 };

    service.getCouponById(1).subscribe(coupon => {
      expect(coupon).toEqual(dummyCoupon);
    });

    const req = httpMock.expectOne('http://localhost:9090/coupon/get/1');
    expect(req.request.method).toBe('GET');
    req.flush(dummyCoupon);
  });

  it('should get a coupon by name', () => {
    const dummyCoupon = { id: 1, couponName: 'ABC', discount: 10 };

    service.getCouponByName('ABC').subscribe(coupon => {
      expect(coupon).toEqual(dummyCoupon);
    });

    const req = httpMock.expectOne('http://localhost:9090/coupon/ABC');
    expect(req.request.method).toBe('GET');
    req.flush(dummyCoupon);
  });

  it('should add a coupon', () => {
    const newCoupon = { id: 3, couponName: 'DEF', discount: 15 ,couponDesc:'get 15 rs off', couponPrice:15, minOrderAmount:100 };

    service.addCoupon(newCoupon).subscribe(coupon => {
      expect(coupon).toEqual(newCoupon);
    });

    const req = httpMock.expectOne('http://localhost:9090/coupon/add');
    expect(req.request.method).toBe('POST');
    req.flush(newCoupon);
  });

  it('should update a coupon', () => {
    const updatedCoupon = { id: 1, couponName: 'ABC', discount: 15, couponDesc:'get 15 rs off', couponPrice:15, minOrderAmount:100 };

    service.updateCoupon(updatedCoupon).subscribe(coupon => {
      expect(coupon).toEqual(updatedCoupon);
    });

    const req = httpMock.expectOne('http://localhost:9090/coupon/update');
    expect(req.request.method).toBe('PUT');
    req.flush(updatedCoupon);
  });

  it('should delete a coupon', () => {
    const id = 1;

    service.deleteCoupon(id).subscribe(() => {
      expect().nothing(); // the method doesn't return anything
    });

    const req = httpMock.expectOne(`http://localhost:9090/coupon/delete/${id}`);
    expect(req.request.method).toBe('DELETE');
    req.flush({});
  });

});