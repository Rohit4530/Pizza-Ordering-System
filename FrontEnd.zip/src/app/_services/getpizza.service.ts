import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Beverage } from '../beverage';
//import { Pizza } from '../home/home.component';
import { Pizza } from '../pizza';
import { Sides } from '../sides';

@Injectable({
  providedIn: 'root'
})
export class GetpizzaService {

  //private baseURL = "http://localhost:8080/pizza/all/orderByPrice";
  // httpClient!: HttpClient;

  constructor(private http: HttpClient) {
  }

  getPizzaList(): Observable<any> {
    return this.http.get<Pizza[]>('http://localhost:9900/pizza/all');

  }
  getPizzaById(id:number): Observable<any> {
    return this.http.get<Pizza[]>('http://localhost:9900/pizza/' + id);

  }
  getSidesList():Observable<any>{
    return this.http.get<Sides[]>('http://localhost:9900/sides/all');
  }
  getBevList():Observable<any>{
    return this.http.get<Beverage[]>('http://localhost:9900/beverages/all');
  }
  getTotal():Observable<any>{
    return this.http.get<any>('http://localhost:9900/cart/products/total');
  }
  
}