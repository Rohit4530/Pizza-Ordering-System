import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AdminService } from './admin.service';
import { Beverage } from '../beverage';
import { Pizza } from '../pizza';
import { Sides } from '../sides';

describe('AdminService', () => {
  let service: AdminService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [AdminService],
    });
    service = TestBed.inject(AdminService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getPizzasList', () => {
    it('should return an Observable<Pizza[]>', () => {
      const mockPizzas: Pizza[] = [
        { id: 1, pizzaName: 'Margarita', pizzaDesc: 'Classic pizza', pizzaPrice: 8.99, imgURL:'',size:'M', pizzaType:'Veg', basePrice: 8.99, pizzaCount:1 },
        { id: 2, pizzaName: 'Pepperoni', pizzaDesc: 'Classic pizza', pizzaPrice: 9.99, imgURL:'',size:'L', pizzaType:'Veg', basePrice: 9.99, pizzaCount:1 },
      ];

      service.getPizzasList().subscribe((pizzas) => {
        expect(pizzas).toEqual(mockPizzas);
      });

      const req = httpMock.expectOne('http://localhost:8080/pizza/all');
      expect(req.request.method).toBe('GET');
      req.flush(mockPizzas);
    });
  });

  describe('getPizzaById', () => {
    it('should return an Observable<Pizza>', () => {
      const mockPizza: Pizza = { id: 1, pizzaName: 'Margarita', pizzaDesc: 'Classic pizza', pizzaPrice: 8.99, imgURL:'',size:'M', pizzaType:'Veg', basePrice: 8.99, pizzaCount:1  };

      service.getPizzaById(1).subscribe((pizza) => {
        expect(pizza).toEqual(mockPizza);
      });

      const req = httpMock.expectOne('http://localhost:8080/pizza/byId/1');
      expect(req.request.method).toBe('GET');
      req.flush(mockPizza);
    });
  });

  describe('updatePizzaList', () => {
    it('should update an existing Pizza', () => {
      const mockPizza: Pizza = { id: 1, pizzaName: 'Margarita', pizzaDesc: 'Classic pizza', pizzaPrice: 8.99, imgURL:'',size:'M', pizzaType:'Veg', basePrice: 8.99, pizzaCount:1 };

      service.updatePizzaList(1, mockPizza).subscribe((pizza) => {
        expect(pizza).toEqual(mockPizza);
      });

      const req = httpMock.expectOne('http://localhost:8080/pizza/update/1');
      expect(req.request.method).toBe('PUT');
      req.flush(mockPizza);
    });
  });

  describe('addPizza', () => {
    it('should add a new Pizza', () => {
      const mockPizza: Pizza = {id: 1, pizzaName: 'Margarita', pizzaDesc: 'Classic pizza', pizzaPrice: 8.99, imgURL:'',size:'M', pizzaType:'Veg', basePrice: 8.99, pizzaCount:1  };

      service.addPizza(mockPizza).subscribe((pizza) => {
        expect(pizza).toEqual(mockPizza);
      });

      const req = httpMock.expectOne('http://localhost:8080/pizza/add');
      expect(req.request.method).toBe('POST');
      req.flush(mockPizza);
    });
  });

  describe('deletePizza', () => {
    it('should make a DELETE request to delete the specified pizza', () => {
      const mockPizza = { id: 1, name: 'Margherita', description: 'Tomato sauce, mozzarella, and basil', price: 10.99 };
      service.deletePizza(1).subscribe();
      const req = httpMock.expectOne('http://localhost:8080/pizza/1');
      expect(req.request.method).toBe('DELETE');
      req.flush({});
    });
  });
})
