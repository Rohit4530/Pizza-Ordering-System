import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../order';
const API_URL='http://localhost:7878/order'
@Injectable({
  providedIn: 'root'
})
export class OrderService {
  finalAmount:number;
  constructor(private http: HttpClient) {

   }


   getOrder(): Observable<any>{
    return this.http.get<Order>(API_URL+'/all');
  }

  addOrder(order: Order){
    //console.log(order);
    
    return this.http.post<Order>(API_URL+'/add', order);
  }

  updateOrderStatus(id:number, status: String){
    
    return this.http.put(API_URL+`/update/${id}/${status}`, id);
  }

  deleteOrder(id:number){
    return this.http.delete(API_URL+`/delete/${id}`);
  }

  getOrderByUserId(id:number): Observable<any>
{
  return this.http.get<Order>(API_URL+`/${id}`)
}

setFinalAmount(finalAmount : number){
 //window.localStorage.setItem('finalAmount', finalAmount.toString());
  this.finalAmount=finalAmount;
}
getFinalAmount(){
  return this.finalAmount;
  //return window.sessionStorage.getItem('finalAmount');
}
}
