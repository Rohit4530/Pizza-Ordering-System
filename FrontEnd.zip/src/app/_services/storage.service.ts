import { Injectable } from '@angular/core';

const USER_KEY = 'auth-user';

@Injectable({
  providedIn: 'root'
})
export class StorageService {
  [x: string]: any;
  constructor() {}
  isSides:boolean=false;
  isSideItem:boolean=false;
  isBev:boolean=false;
  isPizzaItem=false;
  isPlaced:boolean=false;
  
  clean(): void {
    window.sessionStorage.clear();
  }

  public saveUser(user: any): void {
    window.sessionStorage.removeItem(USER_KEY);
    window.sessionStorage.setItem(USER_KEY, JSON.stringify(user));
  }

  public getUser(): any {
    const user = window.sessionStorage.getItem(USER_KEY);
    if (user) {
      return JSON.parse(user);
    }

    return {};
  }

  public isLoggedIn(): boolean {
    const user = window.sessionStorage.getItem(USER_KEY);
    if (user) {
      return true;
    }

    return false;
  }
  public changeStatus(){
     this.isSides=true;
    console.log(this.isSides);
     
  }
  
  public setPlacedFalse(){
    this.isPlaced=false;
  }
  public setPlacedToTrue(){
    this.isPlaced=true;
  }

  public setInsufficientBalTo1(){
    window.sessionStorage.setItem('insufficientBal', "1");
  }

  public setInsufficientBalTo0(){
    window.sessionStorage.setItem('insufficientBal', "0");
  }

  public getInsufficientBal(){
    return window.sessionStorage.getItem('insufficientBal');
  }
}
