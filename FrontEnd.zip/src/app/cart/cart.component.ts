import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Cart } from '../cart';
import { CartServiceService } from '../cart-service.service';
import { Pizza } from '../pizza';
import { GetpizzaService } from '../_services/getpizza.service';
import { StorageService } from '../_services/storage.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  qty: number = 1;
  amount:number
  // afterGst:number= this.getTotalamount();

  grandTotal:number;
  afterGst:number;
  total:number;
  carts: Cart[];
  crust:String[] = [""," New Hand Tossed ", " 100% Wheat Thin Crust ", " Cheese Burst "];
  public isLogIn: boolean;
  cartService: CartServiceService;
  pizzaDetails: Pizza[];
 newCart:Cart;

  constructor(private cartSer: CartServiceService, private storageService: StorageService, private pizzaService: GetpizzaService,private router:Router) {
    this.cartService = cartSer;
  }

  ngOnInit(): void {
   // console.log(this.storageService.isLoggedIn());
    this.isLogIn = this.storageService.isLoggedIn();
    this.getAllCart();
    // this.getpizza(this.carts[0].productId);
  //  console.log(this.carts);
  this.getTotalamount();
  this.gstTotalamount(); 
  }

  // Getting all data from cart based on there id
  public getAllCart(): void {
    this.cartService.getProductFromCart().subscribe(
      (response: Cart[]) => {
        this.carts = response;

        console.log(this.carts);
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    )
  }

  // Function to update number of pizza orders
  public updateMaxQty(input: Cart) {
     if(input.orderCount>=2)
    input.orderCount=input.orderCount-1;
    this.cartService.updateProductToCart(input).subscribe(
      data=>console.log(data)
    )
    window.location.reload();
  }
  public updateMinQty(input: Cart) {
    input.orderCount=input.orderCount+1;
    this.cartService.updateProductToCart(input).subscribe(
      data=>console.log(data)
    )
    window.location.reload();
  }

  // Fetching pizza details from pizza service by usind pizza id
  public getpizza(id: number){

    this.pizzaService.getPizzaById(id).subscribe(
      data => {
      //  console.log(data);
        this.pizzaDetails = data;
      },
      error => {
        console.log(error);
      }
    );   
  }
   public getTotalamount(){
      this.pizzaService.getTotal().subscribe((data)=>{
        this.grandTotal=data;  
        this.total=this.grandTotal*1.18+40;  
      })
      return this.grandTotal;
   }

   public gstTotalamount(){
    this.pizzaService.getTotal().subscribe((data)=>{
      this.afterGst=data*0.18
      console.log(this.afterGst);
      
    })
    // this.afterGst=this.grandTotal*1.18
    return (this.afterGst);
 }

  
  public calculateAmountData(){
    for (const cart of this.carts) {
      this.amount = this.amount ;
     // console.log("Amount : " + this.amount)
    }
  }

  public deleteFromCart(id:number){
    this.cartService.deleteCart(id).subscribe(
      data => {
       // console.log(data);
      },
      error =>{
        console.log(error);
      }
    );
    alert("Item deleted Successfully");
    window.location.reload();
  }



  public cartToOrder(totalCarts:Cart[]){
   this.cartService.getOrderFromCart(totalCarts)
    this.router.navigate(["order"])
  }
 

  Proceed(){
    this.router.navigate(["order"])
  }
}
