import { HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Beverage } from '../beverage';
import { Pizza } from '../pizza';
import { Sides } from '../sides';
import { AdminService } from '../_services/admin.service';
import { StorageService } from '../_services/storage.service';

@Component({
  selector: 'app-admin-pizza',
  templateUrl: './admin-pizza.component.html',
  styleUrls: ['./admin-pizza.component.css']
})


export class AdminPizzaComponent implements OnInit {

  pizzas:Pizza[];
  sides: Sides[];
  beverages: Beverage[];
  type :string;

  isAdmin : boolean = false;
  message: string = "";
  private roles: string[] = [];
  isLoggedIn = false;
  showAdminBoard = false;
  showModeratorBoard = false;

  
  ngOnInit(): void {
    this.refreshMenu();
      const user = this.storageService.getUser();
      this.roles = user.roles;
      this.isAdmin = this.roles.includes('ROLE_ADMIN');
  }

  constructor(private http: HttpClientModule, private adminService: AdminService,private router: Router,private storageService: StorageService,){

  }

 
  refreshMenu(){
    this.adminService.getPizzasList().subscribe(
      response => {
        console.log(response);
        this.pizzas = response;
      }
    )

//Sides
    this.adminService.getSidesList().subscribe(
      response => {
        console.log(response);
        this.sides = response;
      }
    )

//beverages
    this.adminService.getBeveragesList().subscribe(
      response => {
        console.log(response);
        this.beverages = response;
      }
    )
  }



 


  addPizza(){
    this.type = "Pizza";
    this.router.navigate(['editProduct', -1, this.type]);

  }

  deletepizza(id: number){
    
    this.adminService.deletePizza(id).subscribe(
      data => {
        console.log('hi, deleting')
        console.log(`deleted ${id} `)
        console.log(data)
        this.message = (`Deleted pizza ${id} Successfully`)
        this.refreshMenu();

      }

      
    )


  }


  updatepizza(id:number){
    console.log(`updating pizza ${id}`);
    this.type = "Pizza";
    this.router.navigate(['editProduct', id, this.type])

  }





  //sides

  addSides(){
    this.type = "Sides";
    this.router.navigate(['editProduct', -1, this.type]);
  }
  deletesides(id: number){
    
    this.adminService.deleteSides(id).subscribe(
      data => {
        console.log('hi, deleting')
        console.log(`deleted ${id} `)
        console.log(data)
        this.message = (`Deleted side ${id} Successfully`)
        this.refreshMenu();
      } 
    )
  }


  updatesides(id:number){
    console.log(`updating side ${id}`)
    this.type = "Sides";
    this.router.navigate(['editProduct', id, this.type])
  }



  //bevereages

  addBeverages(){
    this.type = "Beverages";
    this.router.navigate(['editProduct', -1, this.type]);
  }
  deletebeverages(id: number){
    
    this.adminService.deleteBeverages(id).subscribe(
      data => {
        console.log('hi, deleting')
        console.log(`deleted ${id} `)
        console.log(data)
        this.message = (`Deleted beverage ${id} Successfully`)
        this.refreshMenu();
      } 
    )
  }


  updatebeverages(id:number){
    console.log(`updating beverage ${id}`)
    this.type = "Beverages";
    this.router.navigate(['editProduct', id, this.type])
  }

}
