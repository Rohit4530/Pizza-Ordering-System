import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from '../cart';
import { CartServiceService } from '../cart-service.service';
import { Coupon } from '../coupon/coupon.component';
import { CouponService } from '../_services/coupon.service';
import { StorageService } from '../_services/storage.service';
import { CartComponent } from '../cart/cart.component';
import { GetpizzaService } from '../_services/getpizza.service';
import { OrderService } from '../_services/order.service';
import { Order } from '../order';
import { DatePipe } from '@angular/common';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  public isLogIn: boolean;


  //forcoupons
  coupons !: Coupon[];
  couponExist: boolean;
  validCoupon: boolean;
  showCoupon: string;
  orderAmount: number = 500;
  coupon: Coupon;
  myCouponAmount: number;
  coupon2: Coupon[];
  flag: boolean;

  subtotal: any;
  discountedAmount: number = 0;
  total: any;
  gst: any;
  deliveryFee: any;
  finalAmount: any;
  order: Order = new Order();
  test: number[] = [];
  addressField: String = "";
  walletAmount: number;
  totalCarts: Cart[];


  constructor(private router: Router, private cartService: CartServiceService, private storageService: StorageService, private couponService: CouponService, private pizzaservice: GetpizzaService, private orderService: OrderService, private customerService: CustomerService) {

  }
  

  ngOnInit(): void {
    this.storageService.setInsufficientBalTo0();
    console.log(this.storageService.getInsufficientBal());
    
    this.pizzaservice.getTotal().subscribe(
      data => {
        this.subtotal = data;
        console.log(this.subtotal);
        this.getApplicableOffers();
        this.calculateTotal();
        this.getWalletAmount();
        this.getCustomerAddress(this.storageService.getUser().id);
      }
    );

    this.isLogIn = this.storageService.isLoggedIn();
    this.cartService.getProductFromCart().subscribe(data => {
      this.totalCarts = data;
    });
    console.log(this.totalCarts);


  }

  getWalletAmount() {
    this.customerService.getWalletAmount(this.storageService.getUser().id).subscribe(
      data => {
        console.log("helloooooooo");

        console.log(data);
        this.walletAmount = data;

      }
    )
  }


  checkAppliedCoupon() {

    this.couponExist = false;
    this.validCoupon = false;
    this.couponService.getCoupons().subscribe(data => {
      this.coupon2 = data;


      for (let i = 0; i < this.coupon2.length; i++) {
        this.flag = true
        console.log(this.coupon2[i]);
        //  console.log(this.showCoupon);

        if (this.coupon2[i].couponName === this.showCoupon) {
          this.couponExist = true;
          console.log(this.flag);
          console.log(this.couponExist);

          console.log(this.coupon2[i].couponPrice);
          this.myCouponAmount = this.coupon2[i].couponPrice;
          this.couponExist = true;
          if (this.coupon2[i].minOrderAmount <= this.subtotal) {
            this.validCoupon = true;
            this.discountedAmount = this.coupon2[i].couponPrice
            break;
          } else {
            this.validCoupon = false;
            break;
          }
        }
      }

      console.log(this.validCoupon);
      console.log(this.couponExist);
      console.log(this.flag);

      if (!this.flag) {

        this.couponExist = false;
      }
    })
  }


  getApplicableOffers() {
    this.couponService.getApplicableCoupon(this.subtotal).subscribe(
      data => {
        this.coupons = data;
        console.log(this.coupons)
      },
      error => {
        console.log(error);

      }
    )
  }

  applyCoupon(couponPrice: number) {
    console.log(couponPrice);
    this.discountedAmount = couponPrice;
    this.calculateTotal();
  }

  calculateTotal() {
    this.total = this.subtotal - this.discountedAmount;
    this.gst = this.total * 0.18;
    this.deliveryFee = 50;
    this.finalAmount = this.total + this.deliveryFee + this.gst;

  }

  placeOrder(add: String) {
    this.orderService.setFinalAmount(this.finalAmount);
    this.order.date = new Date();
    this.order.userId = this.storageService.getUser().id;
    this.cartService.getProductFromCart().subscribe(data => {
      this.totalCarts = data;
      this.order.cart = this.totalCarts;
      this.order.amount = this.finalAmount;
      this.order.address = this.addressField;
      this.order.status = "Order Placed";

      if (this.walletAmount >= this.finalAmount) {
        this.orderService.addOrder(this.order).subscribe(
          data => {
            console.log(data);
          }
        );
        this.orderService.setFinalAmount(this.finalAmount);
        this.storageService.setPlacedToTrue();
        this.router.navigate(['/wallet']);
      }
      else {
        this.storageService.setInsufficientBalTo1();
        alert("Your wallet amount is insufficient. Please add money to wallet");
        this.router.navigate(['/wallet']);

      }

    });

  }

  getCustomerAddress(userId: number) {
    this.customerService.getCustomer(userId).subscribe(
      data => {
        this.addressField = data.address;
      }
    )
  }


}