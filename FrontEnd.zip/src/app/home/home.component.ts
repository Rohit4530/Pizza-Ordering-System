import { Component, OnInit } from '@angular/core';
import { Pizza } from '../pizza';
import { GetpizzaService } from '../_services/getpizza.service';
import { StorageService } from '../_services/storage.service';
import { UserService } from '../_services/user.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Cart } from '../cart';
import { CartServiceService } from '../cart-service.service';
import { CartComponent } from '../cart/cart.component';
import {Sides } from '../sides'
import { SearchService } from '../_shared/search.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  crust:number = 1;
  size:string = "small";
  content?: string;
  pizzaDetails !: Pizza[];
  pizzaService!: GetpizzaService;
  searchTerm:string='';
  Option:string='sort'
  //cartserv:CartServiceService;
  addToCartURL = "http://localhost:9000/cart/product/add";
  constructor(private userService: UserService, pizzaService:GetpizzaService, private storageService : StorageService, private route:Router, private http: HttpClient,private cartservice:CartServiceService, private searchService: SearchService) { 
    this.pizzaService = pizzaService;
    //this.cartservice=this.cartserv;
  }

  cart:Cart = new Cart();
  ngOnInit(): void {
    this.storageService.isPizzaItem=true;
    this.storageService.isBev=false;
    this.storageService.isSideItem=false;
    console.log(this.storageService.isPizzaItem);
    
    console.log("size: "+ this.size + " crust :" +this.crust);
    
    // Fetching all Pizza Data
     
    this.getPizzaDetails()

    this.userService.getPublicContent().subscribe({
      next: data => {
        this.content = data;
      },
      error: err => {
        if (err.error) {
          try {
            const res = JSON.parse(err.error);
            this.content = res.message;
          } catch {
            this.content = `Error with status: ${err.status} - ${err.statusText}`;
          }
        } else {
          this.content = `Error with status: ${err.status}`;
        }
      }
    });
  }

addToCart(pizzaDet:Pizza){
  // If user is loggedIn then collect all pizza data in variables and add data to cart in database
  if(this.storageService.isLoggedIn()){
    this.cart.crustId=this.crust
    this.cart.amount=pizzaDet.pizzaPrice
    this.cart.orderCount=1
    this.cart.size=this.size
    this.cart.userId=this.storageService.getUser().id
    this.cart.productName=pizzaDet.pizzaName
    this.cart.imageUrl=pizzaDet.imgURL;
    this.cart.description=pizzaDet.pizzaDesc
    console.log(this.cart);
    (this.cart);
    this.cartservice.addProductToCart(this.cart).subscribe((data)=>{
        console.log(data);
        window.location.reload();
    });
  
    alert("Pizza is added to cart");
    
  }
  else{
    this.route.navigate(['/login'])
    
  }
  
}

public getPizzaDetails(){
    this.pizzaService.getPizzaList().subscribe(
      data => {
        
          console.log(data);
          this.pizzaDetails = data.map((pizza: { id : any;
                                        pizzaName : any;
                                        pizzaType : any;
                                        pizzaDesc : any;
                                        pizzaPrice : any;
                                        pizzaCount :any;
                                        imgURL: string }) => ({
            ...pizza,
            basePrice: pizza.pizzaPrice,
            size: 'Small'
          }));
          console.log("this is my " + Pizza);
          console.log(this.pizzaDetails);
          console.log(data);
        },
      error => {
        console.log(error);
      }
    )

    this.searchService.currentSearch.subscribe(data => {
      this.searchTerm = data;
  
      console.log(data);
    })
  }

  public selectedCrust(sel: any, crust:any){
    this.crust = crust;
    console.log("size: "+ this.size + " crust :" +this.crust);
  }

  public selectedSize(sel: any, size:any){
    this.size = size;
    console.log("size: "+ this.size + " crust :" +this.crust);
  }


  selectPreference() {
    
    switch (this.Option) {
      case 'default':
        this.getPizzaDetails();
        break;
      case 'price':
        this.pizzaDetails = this.pizzaDetails.slice().sort((a, b) => a.pizzaPrice - b.pizzaPrice);
        break;
      case 'price-desc':
        this.pizzaDetails = this.pizzaDetails.slice().sort((a, b) => b.pizzaPrice - a.pizzaPrice);
        break;
      case 'veg':
        this.pizzaDetails = this.pizzaDetails.filter(pizzaDetails => pizzaDetails.pizzaType === 'Veg');
        break;
      case 'nonveg':
        this.pizzaDetails = this.pizzaDetails.filter(pizzaDetails => pizzaDetails.pizzaType === 'Non-veg');
        break;
      default:
           this.pizzaDetails = this.pizzaDetails;
         break;
      
    }
  }


  // public sortPrice() {
  //   this.pizzaDetails.sort((a, b) => a.pizzaPrice - b.pizzaPrice);
  // }
  // public sortPriceDescending() {
  //   this.pizzaDetails.sort((a, b) => b.pizzaPrice - a.pizzaPrice);
  // }
  


  updatePrice(pizza:Pizza, value:any) {
    this.size = value.target.value;
    console.log(this.size);
    
     pizza.size = this.size;
     console.log(pizza.basePrice);
     
     console.log(pizza.size);
     if (this.size === 'Small') {
       pizza.pizzaPrice = pizza.basePrice + 0;
     } else if (this.size === 'Medium') {
       pizza.pizzaPrice = pizza.basePrice + 150;
     } else if (this.size === 'Large') {
       pizza.pizzaPrice = pizza.basePrice + 280;
     }
   }
  
  
}
