export class Crust{
    crustId:number;
	crustType:string;
	price:number;
}