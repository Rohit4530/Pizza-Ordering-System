import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { BoardUserComponent } from './board-user/board-user.component';
import { BoardModeratorComponent } from './board-moderator/board-moderator.component';
import { BoardAdminComponent } from './board-admin/board-admin.component';
import { ForgetComponent } from './forget/forget.component';
import { AddpizzaComponent } from './addpizza/addpizza.component';
import { CartComponent } from './cart/cart.component';
import { SidesComponent } from './sides/sides.component';
import { BeveragesComponent } from './beverages/beverages.component';
import { OrderComponent } from './order/order.component';
import { WalletComponent } from './wallet/wallet.component';
import { CouponComponent } from './coupon/coupon.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { AdminPizzaComponent } from './admin-pizza/admin-pizza.component';
import { ErrorComponent } from './error/error.component';
import { SuccessComponent } from './success/success.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'user', component: BoardUserComponent },
  { path: 'mod', component: BoardModeratorComponent },
  { path: 'admin', component: BoardAdminComponent },
  { path: 'forget', component: ForgetComponent },
  { path: 'addpizza', component: AddpizzaComponent },
  { path: 'cart', component: CartComponent},
  {path: 'sides',component:SidesComponent},
  {path:'bev',component:BeveragesComponent},
  {path:'order',component:OrderComponent},
  {path:'wallet',component:WalletComponent},
  {path: 'editProduct/:id/:type', component: ProductEditComponent},
  {path: 'adminPizza', component: AdminPizzaComponent},
  {path:'coupons', component:CouponComponent},
  {path:'orderHistory', component:OrderHistoryComponent},
  {path:'success',component:SuccessComponent},
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  {path:'**', component:ErrorComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
