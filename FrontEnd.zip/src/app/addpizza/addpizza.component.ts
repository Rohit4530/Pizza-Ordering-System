import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-addpizza',
  templateUrl: './addpizza.component.html',
  styleUrls: ['./addpizza.component.css']
})
export class AddpizzaComponent {
  private baseUrl = "http://localhost:8080/pizza/add";
  constructor(private http:HttpClient){}
  
  onSubmit(data: any){
    this.http.post(this.baseUrl,data).subscribe(
      (res) => {
        alert("Data entered succesfully");
        window.location.reload();
      }
    )
  }

}

