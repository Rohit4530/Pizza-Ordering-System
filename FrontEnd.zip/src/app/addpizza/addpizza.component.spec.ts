import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';

import { AddpizzaComponent } from './addpizza.component';

describe('AddpizzaComponent', () => {
  let component: AddpizzaComponent;
  let fixture: ComponentFixture<AddpizzaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddpizzaComponent ],
      imports:[HttpClientModule, FormsModule]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddpizzaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
