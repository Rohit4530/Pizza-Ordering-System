import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Beverage } from '../beverage';
import { Cart } from '../cart';
import { CartServiceService } from '../cart-service.service';
import { GetpizzaService } from '../_services/getpizza.service';
import { StorageService } from '../_services/storage.service';
import { UserService } from '../_services/user.service';
import { SearchService } from '../_shared/search.service';

@Component({
  selector: 'app-beverages',
  templateUrl: './beverages.component.html',
  styleUrls: ['./beverages.component.css']
})
export class BeveragesComponent {
  cart:Cart = new Cart();
  pizzaService!: GetpizzaService;
  BeveragesDetail:Beverage[];
  searchTerm:string='';
  ngOnInit(): void {
    this.getBevragesDetails();
  }
  constructor(private userService: UserService, pizzaService:GetpizzaService, private storageService : StorageService, private route:Router, private http: HttpClient,private cartservice:CartServiceService, private searchService: SearchService) { 
    this.pizzaService = pizzaService;
    //this.cartservice=this.cartserv;
  }

  addToCartBev(bev:Beverage){
    // If user is loggedIn then collect all pizza data in variables and add data to cart in database
    if(this.storageService.isLoggedIn()){
      this.cart.amount=bev.beveragePrice
      this.cart.orderCount=1
      this.cart.size=bev.beverageQuant
      this.cart.userId=this.storageService.getUser().id
      this.cart.productName=bev.beverageName
      this.cart.imageUrl=bev.imgURL
      this.cart.description=bev.beverageDisc
      console.log(this.cart);
      (this.cart);
      this.cartservice.addProductToCart(this.cart).subscribe((data)=>{
          console.log(data);
          window.location.reload();
      });
    
      alert("side is added to cart");
      
    }
    else{
      this.route.navigate(['/login'])
      
    }
  }
    public getBevragesDetails(){
      this.pizzaService.getBevList().subscribe(
        data => {
          console.log(data);
          this.BeveragesDetail= data;
          console.log(this.BeveragesDetail);
          
        },
        error => {
          console.log(error);
        }
      )

      this.searchService.currentSearch.subscribe(data => {
        this.searchTerm = data;
    
        console.log(data);
      })
    }
}
