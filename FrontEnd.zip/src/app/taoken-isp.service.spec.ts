import { HttpClientModule } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';

import { TAokenIspService } from './taoken-isp.service';

describe('TAokenIspService', () => {
  let service: TAokenIspService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports:[HttpClientModule]
    });
    service = TestBed.inject(TAokenIspService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
