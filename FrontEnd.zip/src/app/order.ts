import { Cart } from "./cart";

export class Order {
    id:number;
    userId:number;
    cart:Cart[]
    date:Date;
    status: String;
    amount:number;
    address:String;
}
