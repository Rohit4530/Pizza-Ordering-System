import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  API_URL = "http://localhost:9900/api/customer";
  insufficientBal : boolean = false;
  constructor(private http: HttpClient) { }
  addCustomer(cust: Customer): Observable<any> {
    return this.http.post<Customer>(`${this.API_URL}/add`, cust);
  }
  getCustomer(userId: number): Observable<any> {
    return this.http.get<Customer>(`${this.API_URL + "/" + userId}`);
  }
  deleteCustomer(id: number): Observable<any> {
    console.log(id);

    return this.http.delete(`${this.API_URL + "/delete/" + id}`);
  }
  updateCustomer(cust: Customer): Observable<any> {
    return this.http.put<Customer>(`${this.API_URL}/update`, cust);
  }
  getWalletAmount(userid: number): Observable<number> {
    return this.http.get<number>(`${this.API_URL}/${userid}/wallet`);
  }
  setWalletAmount(userid: number, walletamount: number): Observable<any> {
    return this.http.put<number>(this.API_URL +"/"+ userid + "/" + walletamount, userid);
  }

  payFromWallet(userId:number, paymentAmount:number){
    return this.http.put<number>(this.API_URL+"/pay/"+userId+"/"+paymentAmount, paymentAmount);
  }

  setInsufficientAmountTrue(){
    this.insufficientBal = true;
  }

  setInsufficientAmountFalse(){
    this.insufficientBal = false;
  }
}
