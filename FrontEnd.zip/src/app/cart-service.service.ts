import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Cart } from './cart';

@Injectable({
  providedIn: 'root'
})
export class CartServiceService {
  apiUrl:string="http://localhost:9900/cart" ;
  totalCart:Cart[];

  constructor(private http:HttpClient) { }
  public getProductFromCart():Observable<Cart[]>{
  return  this.http.get<Cart[]>(`${this.apiUrl}/products`);
  }
  public addProductToCart(cart:Cart):Observable<Cart>{
   return this.http.post<Cart>(`${this.apiUrl}/product/add`,cart);
  }
  public deleteCart(id:number){
    return this.http.delete(this.apiUrl+"/product/delete/"+id);
  }
  public updateProductToCart(cart:Cart):Observable<Cart>{
    return this.http.put<Cart>(`${this.apiUrl}/product/update`,cart);
   }

   public getOrderFromCart(totalCarts:Cart[]){
     this.totalCart=totalCarts
      return totalCarts;
   }

   public getCart(){
    return this.totalCart;
 }
}
