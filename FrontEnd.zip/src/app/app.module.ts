import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap'; 

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { BoardAdminComponent } from './board-admin/board-admin.component';
import { BoardModeratorComponent } from './board-moderator/board-moderator.component';
import { BoardUserComponent } from './board-user/board-user.component';

import { httpInterceptorProviders } from './_helpers/http.interceptor';
import { TAokenIspService } from './taoken-isp.service';
import { ForgetComponent } from './forget/forget.component';
import { AddpizzaComponent } from './addpizza/addpizza.component';
import { CartComponent } from './cart/cart.component';
import { SidesComponent } from './sides/sides.component';
import { BeveragesComponent } from './beverages/beverages.component';
import { OrderComponent } from './order/order.component';
import { WalletComponent } from './wallet/wallet.component';
import { CouponComponent } from './coupon/coupon.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { AdminPizzaComponent } from './admin-pizza/admin-pizza.component';
import { ProductEditComponent } from './product-edit/product-edit.component';
import { FilterPipe } from './filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    ProfileComponent,
    BoardAdminComponent,
    BoardModeratorComponent,
    BoardUserComponent,
    ForgetComponent,
    AddpizzaComponent,
    CartComponent,
    SidesComponent,
    BeveragesComponent,
    OrderComponent,
    WalletComponent,
    CouponComponent,
    OrderHistoryComponent,
    AdminPizzaComponent,
    ProductEditComponent,
    FilterPipe,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    ReactiveFormsModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: TAokenIspService,
    multi:true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
