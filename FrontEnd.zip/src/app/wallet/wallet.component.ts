import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { GetpizzaService } from '../_services/getpizza.service';
import { OrderService } from '../_services/order.service';
import { StorageService } from '../_services/storage.service';

@Component({
  selector: 'app-wallet',
  templateUrl: './wallet.component.html',
  styleUrls: ['./wallet.component.css']
})
export class WalletComponent implements OnInit{
myMoney:number= 0 
addedMoney:number;
isPlaced:boolean=false;
finalAmount :any;
insufficientBal : boolean;

constructor(private service:CustomerService,private storageService:StorageService, private orderService: OrderService, private route: Router){

}
  ngOnInit(): void {
   this.service.getWalletAmount(this.storageService.getUser().id).subscribe(data=>{
      this.myMoney=data;
    })
    this.isPlaced=this.storageService.isPlaced
    this.finalAmount = this.orderService.getFinalAmount();
    console.log(this.finalAmount);
    
    this.insufficientBal = this.storageService.getInsufficientBal() == "1";

  
  }
  addMoney(){
    this.service.setWalletAmount(this.storageService.getUser().id,this.addedMoney).subscribe((data)=>{
      console.log(data);
      
      window.location.reload()
    })
  
  }
  addHundred(){
    this.service.setWalletAmount(this.storageService.getUser().id,100).subscribe((data)=>{
      console.log(data);
      // console.log(this.finalAmount+"hello");
      
      window.location.reload()
    })
  }
  addFiveHundred(){
    this.service.setWalletAmount(this.storageService.getUser().id,500).subscribe((data)=>{
      console.log(data);
      
      window.location.reload()
    })
  }
  addThousand(){
    this.service.setWalletAmount(this.storageService.getUser().id,1000).subscribe((data)=>{
      console.log(data);
      
      window.location.reload()
    })
  }
  saveClicked(){
    this.storageService.setPlacedFalse();
    this.isPlaced=true;
  }
  
  doPayment(amount:number){
    
    this.service.payFromWallet(this.storageService.getUser().id,Math.round(amount)).subscribe(
      data => {
        console.log(data);
        alert("Your Payment is Successfull");
        this.route.navigate(['/success']);
      },
      error=>{
        console.log(error);
        
      }
    )
    
  }

  naviagteToOrder(){
    this.route.navigate(["/order"]);
  }
}
