import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ClipboardModule } from 'ngx-clipboard';
import { CouponService } from '../_services/coupon.service';
import { ClipboardService } from 'ngx-clipboard';
import { GetpizzaService } from '../_services/getpizza.service';
import { StorageService } from '../_services/storage.service';



@Component({
  selector: 'app-coupon',
  templateUrl: './coupon.component.html',
  styleUrls: ['./coupon.component.css']
})
export class CouponComponent implements OnInit{

  private roles: string[] = [];
  isLoggedIn = false;
  showAdminBoard = false;
  coupons !: Coupon[];
  message:string='';
  showForm = false;
  couponToUpdate: any = {};

  
  
  constructor(private couponService: CouponService,  private route:Router, private http: HttpClient, private clipboard: ClipboardService,private pizzaservice:GetpizzaService, private storageService: StorageService) { 
  }


  ngOnInit(): void {
    

    this.isLoggedIn = this.storageService.isLoggedIn();

    if (this.isLoggedIn) {
      const user = this.storageService.getUser();
      this.roles = user.roles;

      this.showAdminBoard = this.roles.includes('ROLE_ADMIN');
    }
    //   if(!this.showAdminBoard){
    // this.getOrderDetails(this.storageService.getUser().id);
    //   }
    //   else{
    //     this.getAdminOrderDetails();
    //   }
   this.couponService.getCoupons().subscribe(
    data=>{
      this.coupons = data;
    },
    error=>{
      console.log(error);
    }
     
   )
   
   
    // throw new Error('Method not implemented.');
  }


  getCoupon(couponName: string){
    console.log(couponName)
    this.clipboard.copyFromContent(couponName);
    this.message=`${couponName} copied to clipboard`;
    alert(this.message)
    this.route.navigate(['home']);
    
    console.log(this.message);

  }



  showUpdateForm(coupon: any) {
    this.couponToUpdate = coupon;
    this.showForm = true;
  }

  updateCoupon(coupon:any){
    this.couponService.updateCoupon(coupon);
    this.showForm=false
  }


  deleteCoupon(id:number){
    this.couponService.deleteCoupon(id);
  }

}

export class Coupon{
  id: number;
  couponName: string;
  couponDesc: string;
  couponPrice: number;
  minOrderAmount: number;
}
