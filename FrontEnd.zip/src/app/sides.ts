export class Sides{
    id:number
	 sideName:string
	 sideType:string 
     sideDesc:string
	 sidePrice:number
	 sideCount: number
	 imgURL:String 
}