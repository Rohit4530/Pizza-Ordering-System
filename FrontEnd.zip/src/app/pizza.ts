export class Pizza {
    id : any;
    pizzaName : any;
    pizzaType : any;
    pizzaDesc : any;
    pizzaPrice : any;
    pizzaCount :any;
    imgURL!: String;
    size:string;
    basePrice:any;
    // crustid!: number;
}
