import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';
import { StorageService } from '../_services/storage.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  id:number;
  fname:any;
  lname:any;
  phone:any;
  address:any;
  currentUser: any;
  hasProfile:boolean=false;
  isLoggedInUser=this.storageService.isLoggedIn()
  cust:Customer=new Customer();
  profileForm=new FormGroup({
    fname:new FormControl("",[Validators.required,Validators.maxLength(20)]),
    lname:new FormControl("",[Validators.required,Validators.maxLength(20)]),
    phone:new FormControl("",[Validators.required,Validators.maxLength(10),Validators.minLength(10)]),
    address:new FormControl("",[Validators.required,Validators.maxLength(60)])
  })
  profileFun(){
  this.fname=this.profileForm.value.fname
  this.cust.firstName=this.profileForm.value.fname
  this.cust.lastName=this.profileForm.value.lname
  this.cust.phone=this.profileForm.value.phone
  this.cust.userId=this.storageService.getUser().id
  this.cust.address=this.profileForm.value.address
  this.cust.id=this.id;
  this.customerService.updateCustomer(this.cust).subscribe((data)=>{
    console.log(data); 
  })
  this.hasProfile=true;
  this.router.navigate(["/profile"]) 
   window.location.reload();
  }
  edit(){
    this.customerService.getCustomer(this.storageService.getUser().id).subscribe((data)=>{
    console.log(data.id);
    this.customerService.deleteCustomer(data.id);
    })
    this.hasProfile=false;
    this.router.navigate(["/profile"]);
  }
  constructor(private storageService: StorageService,private customerService:CustomerService,private router:Router) { }

  ngOnInit(): void {
    this.currentUser = this.storageService.getUser().username;
    console.log(this.isLoggedInUser);
    if(!this.isLoggedInUser){
      this.router.navigate(["/login"])
    }
    this.customerService.getCustomer(this.storageService.getUser().id).subscribe((data)=>{
      this.fname=data.firstName
      this.lname=data.lastName
      this.phone=data.phone
      this.address=data.address
      this.hasProfile=true;
      this.id=data.id
    },
    error => {
      this.hasProfile=false;
    }
    )
  }

  showWallet(){
    this.router.navigate(['wallet'])
  }
  showOrder(){
    this.router.navigate(['orderHistory']);
  }
}
