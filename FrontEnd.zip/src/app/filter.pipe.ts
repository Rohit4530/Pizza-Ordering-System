import { Pipe, PipeTransform } from '@angular/core';
import { StorageService } from './_services/storage.service';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  constructor(private storageService:StorageService){}
  
  transform(items: any[], searchText: string): any[] {
    if (!items) return [];
    if (!searchText) return items;
    searchText = searchText.toLowerCase();
    console.log(items)
    return items.filter(item => {
     
      if(this.storageService.isPizzaItem==true){
      return item.pizzaName.toLowerCase().includes(searchText);
      }
      else if(this.storageService.isSideItem==true){
        return item.sideName.toLowerCase().includes(searchText);
      }
      else{
        return item.beverageName.toLowerCase().includes(searchText);
      }
    });
  }
}
