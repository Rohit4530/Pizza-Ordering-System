import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Beverage } from '../beverage';
import { Pizza } from '../pizza';
import { Sides } from '../sides';
import { AdminService } from '../_services/admin.service';


@Component({
  selector: 'app-product-edit',
  templateUrl: './product-edit.component.html',
  styleUrls: ['./product-edit.component.css']
})
export class ProductEditComponent implements OnInit{


  id:number;
  type:String;
  pizza:Pizza;
  side:Sides;
  beverage:Beverage;
  file: File;
  loading: boolean = false;



  uploadedImage: File;
  


  isPizza:boolean=false;
  isSides:boolean=false;
  isBeverages:boolean=false;
  constructor(private adminService :AdminService, private route: ActivatedRoute, private router : Router, private httpClient: HttpClient ){

  }
  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.type = this.route.snapshot.params['type'];
    console.log(this.type);
    if(this.type=="Pizza"){
      this.isPizza=true;
    this.pizza = new Pizza();
    this.adminService.getPizzaById(this.id).subscribe(
     data => {this.pizza = data,
      console.log(data.pizzaName)},
      error=>{
        console.log("Doesn't exist, adding new Pizza");
        
      }
    )
    //throw new Error('Method not implemented.');
   }


   else if(this.type=="Sides"){
    this.isSides=true;
    this.side = new Sides();
    this.adminService.getSidesById(this.id).subscribe(
     data => {this.side = data,
      console.log(data.sideName)},
      error=>{
        console.log("Doesn't exist, adding new Side");
        
      }
    )
    //throw new Error('Method not implemented.');
   }

   else if(this.type=="Beverages"){
    this.isBeverages=true;
    this.beverage = new Beverage();
    this.adminService.getBeveragesById(this.id).subscribe(
     data => {this.beverage = data,
      console.log(data.beverageName)},
      error=>{
        console.log("Doesn't exist, adding new Beverage");
        
      }
    )
    //throw new Error('Method not implemented.');
   }


  }

  onImageUpload(event:any) {
    this.uploadedImage = event.target.files[0];
    console.log(this.uploadedImage)
    //this.pizza.imgURL= this.file;
}

imageUploadAction() {
  const imageFormData = new FormData();
  if(this.uploadedImage){
   
  
  imageFormData.append('image', this.uploadedImage, this.uploadedImage.name);


  this.httpClient.post('http://localhost:9900/pizza/upload-image', imageFormData, { responseType: 'text' })
    .subscribe((response) => {

      if(this.isPizza){
        this.pizza.imgURL=response;
      }
      else if(this.isBeverages){
        this.beverage.imgURL=response;
      }
      else{
        this.side.imgURL=response;
      }
      console.log(response);
    },
    error=>{
      console.log("me error");
        }
    );

      }
      else{
        alert("Choose Image first before uploading")
      }
  }


// onUpload() {
//   this.loading = !this.loading;
//   console.log(this.file);
//   this.adminService.(this.file).subscribe(
//       (event: any) => {
//           if (typeof (event) === 'object') {

//               // Short link via api response
//              // this.shortLink = event.link;

//               this.loading = false; // Flag variable 
//           }
//       }
//   );
// }

  savepizza(){
    this.adminService.updatePizzaList(this.id, this.pizza).subscribe(
      data =>{
        console.log(data)
        this.router.navigate(['adminPizza'])
      },
      error =>{
        console.log("Encountered error updating");
      }
      
    )
  }


  saveSide(){
    this.adminService.updateSidesList(this.id, this.side).subscribe(
      data =>{
        console.log(data)
        this.router.navigate(['adminPizza'])
      },
      error =>{
        console.log("Encountered error updating");
      }
      
    )
  }

  saveBeverage(){
    this.adminService.updateBeveragesList(this.id, this.beverage).subscribe(
      data =>{
        console.log(data)
        this.router.navigate(['adminPizza'])
      },
      error =>{
        console.log("Encountered error updating");
      }
      
    )
  }

}
